autowatch = 1;
inlets = 1;
outlets = 3;

// Outlet 0: list of 12 linear gains in 7.1.4 order:
// L R C LFE Ls Rs Lrs Rrs Ltf Rtf Ltr Rtr
// Outlet 1: named gain messages, useful for debugging/routing helpers.
// Outlet 2: current state dictionary as a flat list.

var state = {
  x: 0.0,
  y: 0.0,
  z: 0.0,
  spread: 50.0,
  focus: 50.0,
  width: 0.0,
  smooth: 80.0,
  distance: 0.0,
  gain_db: 0.0,
  lfe_send: 0.0,
  lfe_xover: 80.0
};

var fullRangeSpeakers = [
  { name: "L",   x: -0.85, y:  0.85, z: 0.0 },
  { name: "R",   x:  0.85, y:  0.85, z: 0.0 },
  { name: "C",   x:  0.00, y:  1.00, z: 0.0 },
  { name: "Ls",  x: -1.00, y:  0.00, z: 0.0 },
  { name: "Rs",  x:  1.00, y:  0.00, z: 0.0 },
  { name: "Lrs", x: -0.85, y: -0.85, z: 0.0 },
  { name: "Rrs", x:  0.85, y: -0.85, z: 0.0 },
  { name: "Ltf", x: -0.75, y:  0.75, z: 1.0 },
  { name: "Rtf", x:  0.75, y:  0.75, z: 1.0 },
  { name: "Ltr", x: -0.75, y: -0.75, z: 1.0 },
  { name: "Rtr", x:  0.75, y: -0.75, z: 1.0 }
];

var order714 = ["L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs", "Ltf", "Rtf", "Ltr", "Rtr"];

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

function dbToAmp(db) {
  if (db <= -90.0) {
    return 0.0;
  }
  return Math.pow(10.0, db / 20.0);
}

function msg_float(v) {
  // First inlet float maps to X for quick Max testing.
  setParam("x", v);
}

function list() {
  var a = arrayfromargs(arguments);
  if (a.length >= 3) {
    state.x = clamp(a[0], -1.0, 1.0);
    state.y = clamp(a[1], -1.0, 1.0);
    state.z = clamp(a[2], 0.0, 1.0);
    bang();
  }
}

function x(v) { setParam("x", v); }
function y(v) { setParam("y", v); }
function z(v) { setParam("z", v); }
function spread(v) { setParam("spread", v); }
function focus(v) { setParam("focus", v); }
function width(v) { setParam("width", v); }
function smooth(v) { setParam("smooth", v); }
function distance(v) { setParam("distance", v); }
function gain(v) { setParam("gain_db", v); }
function gain_db(v) { setParam("gain_db", v); }
function lfe(v) { setParam("lfe_send", v); }
function lfe_send(v) { setParam("lfe_send", v); }
function lfe_xover(v) { setParam("lfe_xover", v); }
function reset_xy() {
  state.x = 0.0;
  state.y = 0.0;
  bang();
}

function reset_z() {
  state.z = 0.0;
  bang();
}

function reset_all() {
  reset();
}

function setParam(name, value) {
  if (name === "x" || name === "y") {
    state[name] = clamp(value, -1.0, 1.0);
  } else if (name === "z" || name === "width" || name === "distance" || name === "lfe_send") {
    state[name] = clamp(value, 0.0, 1.0);
  } else if (name === "spread" || name === "focus") {
    state[name] = clamp(value, 0.0, 100.0);
  } else if (name === "smooth") {
    state[name] = clamp(value, 0.0, 1000.0);
  } else if (name === "gain_db") {
    state[name] = clamp(value, -90.0, 6.0);
  } else if (name === "lfe_xover") {
    state[name] = clamp(value, 30.0, 200.0);
  }
  bang();
}

function bang() {
  var gainsByName = computeGains(state.x, state.y, state.z);
  var out = [];
  var i;

  for (i = 0; i < order714.length; i += 1) {
    out.push(gainsByName[order714[i]] || 0.0);
  }

  outlet(0, out);

  for (i = 0; i < order714.length; i += 1) {
    outlet(1, order714[i], gainsByName[order714[i]] || 0.0);
  }

  outlet(2,
    "x", state.x,
    "y", state.y,
    "z", state.z,
    "spread", state.spread,
    "focus", state.focus,
    "width", state.width,
    "smooth", state.smooth,
    "distance", state.distance,
    "gain_db", state.gain_db,
    "lfe_send", state.lfe_send,
    "lfe_xover", state.lfe_xover
  );
}

function computeGains(x, y, z) {
  var spread = state.spread / 100.0;
  var focusNorm = clamp(state.focus / 100.0, 0.0, 1.0);
  var focusExp = 1.0 + focusNorm * 3.0;
  var centerWeight = Math.sqrt(spread * Math.sqrt(focusExp) *
    clamp(1.0 - (x * x + y * y), 0.0, 1.0));
  var size = (0.525 * (1.0 - centerWeight)) + (centerWeight * 0.25);
  var speakerScale = 8.0;
  var outputAmp = dbToAmp(state.gain_db);
  var distanceAmp = 1.0 - state.distance * 0.55;
  var weights = [];
  var sumSquares = 0.0;
  var i;

  for (i = 0; i < fullRangeSpeakers.length; i += 1) {
    var sp = fullRangeSpeakers[i];
    var dx = x - sp.x;
    var dy = y - sp.y;
    var dz = (z - sp.z) * 1.15;
    var d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    var db = -Math.pow(d * size * speakerScale, focusExp);
    var weight = dbToAmp(db);
    weights.push(weight);
    sumSquares += weight * weight;
  }

  var norm = sumSquares > 0.0 ? Math.sqrt(sumSquares) : 1.0;
  var gains = {};

  for (i = 0; i < fullRangeSpeakers.length; i += 1) {
    gains[fullRangeSpeakers[i].name] = (weights[i] / norm) * outputAmp * distanceAmp;
  }

  gains.LFE = state.lfe_send * outputAmp;
  return gains;
}

function reset() {
  state.x = 0.0;
  state.y = 0.0;
  state.z = 0.0;
  state.spread = 50.0;
  state.focus = 50.0;
  state.width = 0.0;
  state.smooth = 80.0;
  state.distance = 0.0;
  state.gain_db = 0.0;
  state.lfe_send = 0.0;
  state.lfe_xover = 80.0;
  bang();
}
