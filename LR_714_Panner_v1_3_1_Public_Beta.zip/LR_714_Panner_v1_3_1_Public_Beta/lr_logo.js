autowatch = 1;
inlets = 1;
outlets = 0;

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

function paint() {
  var r = box.rect;
  var w = r[2] - r[0];
  var h = r[3] - r[1];

  with (mgraphics) {
    set_source_rgba(0.0, 0.0, 0.0, 1.0);
    rectangle(0, 0, w, h);
    fill();

    set_source_rgba(1.0, 1.0, 1.0, 1.0);
    select_font_face("Arial");
    set_font_size(Math.max(10, h * 0.42));
    move_to(w * 0.04, h * 0.64);
    show_text("L+R SOUNDSYSTEM");
  }
}
