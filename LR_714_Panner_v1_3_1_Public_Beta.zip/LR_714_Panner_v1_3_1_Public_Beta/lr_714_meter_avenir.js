autowatch = 1;
inlets = 1;
outlets = 0;

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

var labels = ["L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs", "Ltf", "Rtf", "Ltr", "Rtr"];
var values = [];
var peaks = [];

for (var i = 0; i < labels.length; i += 1) {
  values[i] = 0.0;
  peaks[i] = 0.0;
}

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

function list() {
  var a = arrayfromargs(arguments);
  for (var i = 0; i < labels.length; i += 1) {
    var v = i < a.length ? clamp(a[i], 0.0, 1.0) : 0.0;
    values[i] = v;
    peaks[i] = Math.max(v, peaks[i] * 0.94);
  }
  mgraphics.redraw();
}

function reset() {
  for (var i = 0; i < labels.length; i += 1) {
    values[i] = 0.0;
    peaks[i] = 0.0;
  }
  mgraphics.redraw();
}

function paint() {
  var r = box.rect;
  var w = r[2] - r[0];
  var h = r[3] - r[1];
  var marginX = 6;
  var top = 16;
  var bottom = h - 14;
  var barH = Math.max(20, bottom - top);
  var slot = (w - marginX * 2) / labels.length;
  var barW = Math.max(5, Math.min(11, slot * 0.45));

  with (mgraphics) {
    set_source_rgba(0.020, 0.022, 0.026, 1.0);
    rectangle(0, 0, w, h);
    fill();

    set_source_rgba(0.10, 0.11, 0.13, 1.0);
    rectangle(0.5, 0.5, w - 1, h - 1);
    set_line_width(1.0);
    stroke();

    select_font_face("Avenir Next Condensed");
    set_font_size(8);

    for (var i = 0; i < labels.length; i += 1) {
      var x = marginX + slot * i + (slot - barW) * 0.5;
      var v = values[i];
      var peak = peaks[i];
      var fillH = barH * v;
      var peakY = bottom - barH * peak;

      set_source_rgba(0.040, 0.044, 0.052, 1.0);
      rectangle(x, top, barW, barH);
      fill();

      set_source_rgba(0.10, 0.11, 0.13, 0.75);
      for (var tick = 0; tick < 6; tick += 1) {
        var ty = top + (barH / 6) * tick;
        rectangle(x, ty, barW, 1);
        fill();
      }

      if (v > 0.72) {
        set_source_rgba(0.96, 0.58, 0.05, 0.95);
      } else if (v > 0.42) {
        set_source_rgba(0.94, 0.78, 0.05, 0.95);
      } else {
        set_source_rgba(0.18, 0.78, 0.38, 0.95);
      }
      rectangle(x, bottom - fillH, barW, fillH);
      fill();

      set_source_rgba(0.98, 0.82, 0.10, 0.95);
      rectangle(x - 1, peakY, barW + 2, 1.4);
      fill();

      set_source_rgba(0.90, 0.91, 0.92, 1.0);
      move_to(marginX + slot * i + slot * 0.5 - labels[i].length * 2.0, h - 4);
      show_text(labels[i]);
    }
  }
}
