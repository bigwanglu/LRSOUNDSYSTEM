LR_714_Panner_v1_3_1 Public Beta

先读这个文件，再读「使用说明_LR_714_Panner_v1_3_1.md」。
如果解压后中文文件名显示乱码，直接读 Manual_LR_714_Panner_v1_3_1_CN.md，内容相同。

安装原则：
1. 解压后保留整个文件夹，不要只单独拷贝 .amxd。
2. 推荐放到 Ableton User Library:
   ~/Music/Ableton/User Library/Presets/Audio Effects/Max Audio Effect/LR_714_Panner_v1_3_1_Public_Beta/
3. 在 Live 里把 LR_714_Panner_v1_3_1.amxd 拖到 Audio Track 上。
4. 这条轨道的 Audio To 必须设置成 Sends Only，不要走 Main。
5. 在插件右侧 ROUTING 区，把 1/2 到 11/12 分别设置成 Ext. Out 对应的输出对。

7.1.4 通道顺序：
1 L
2 R
3 C
4 LFE
5 Ls
6 Rs
7 Lrs
8 Rrs
9 Ltf
10 Rtf
11 Ltr
12 Rtr

包内文件不要拆开：
LR_714_Panner_v1_3_1.amxd
BrowseRoutingInline_avenir.maxpat
RoutingObjects.maxpat
lr_714_gains_comfy.js
lr_714_pad_avenir_bigger.js
lr_714_meter_avenir.js
lr_714_testfreq.js
lr_logo.js
使用说明_LR_714_Panner_v1_3_1.md
版本说明_v1_3_1.txt
Manual_LR_714_Panner_v1_3_1_CN.md
ReleaseNotes_v1_3_1_CN.txt
