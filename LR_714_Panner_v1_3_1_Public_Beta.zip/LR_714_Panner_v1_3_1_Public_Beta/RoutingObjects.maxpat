{
  "patcher": {
    "fileversion": 1,
    "appversion": {
      "major": 8,
      "minor": 0,
      "revision": 0,
      "architecture": "x64",
      "modernui": 1
    },
    "rect": [
      34,
      79,
      868,
      714
    ],
    "bglocked": 0,
    "openinpresentation": 0,
    "default_fontsize": 12,
    "default_fontface": 0,
    "default_fontname": "Arial",
    "gridonopen": 2,
    "gridsize": [
      10,
      10
    ],
    "gridsnaponopen": 2,
    "objectsnaponopen": 0,
    "statusbarvisible": 2,
    "toolbarvisible": 1,
    "lefttoolbarpinned": 0,
    "toptoolbarpinned": 0,
    "righttoolbarpinned": 0,
    "bottomtoolbarpinned": 0,
    "toolbars_unpinned_last_save": 0,
    "tallnewobj": 0,
    "boxanimatetime": 200,
    "enablehscroll": 1,
    "enablevscroll": 1,
    "devicewidth": 0,
    "description": "",
    "digest": "",
    "tags": "",
    "style": "Max For Live",
    "subpatcher_template": "Max For Live",
    "boxes": [
      {
        "box": {
          "id": "obj-22",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            640,
            690,
            56,
            22
          ],
          "presentation_rect": [
            640,
            690,
            56,
            22
          ],
          "style": "",
          "text": "deferlow"
        }
      },
      {
        "box": {
          "fontface": 1,
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-43",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            200,
            26,
            284,
            20
          ],
          "presentation_rect": [
            200,
            26,
            284,
            20
          ],
          "prototypename": "M4L.patcher-summary",
          "style": "",
          "text": "A utility used by the BrowseRouting abstraction"
        }
      },
      {
        "box": {
          "fontface": 1,
          "fontname": "Arial",
          "fontsize": 18,
          "id": "obj-5",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            50,
            20,
            144,
            27
          ],
          "presentation_rect": [
            50,
            20,
            144,
            27
          ],
          "prototypename": "M4L.subpatcher-title",
          "style": "",
          "text": "RoutingObjects"
        }
      },
      {
        "box": {
          "id": "obj-17",
          "linecount": 3,
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            50,
            50,
            560,
            47
          ],
          "presentation_linecount": 3,
          "presentation_rect": [
            50,
            50,
            560,
            47
          ],
          "style": "",
          "text": "The BrowseRouting abstraction is a utility that lists available tracks in the current Live set to send audio to or receive audio from, to be used inside a multichannel Max For Live device. The RoutingObjects abstraction is the mechanism used to list and map available audio inputs and outputs."
        }
      },
      {
        "box": {
          "id": "obj-28",
          "linecount": 2,
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            490,
            540,
            80,
            35
          ],
          "presentation_linecount": 2,
          "presentation_rect": [
            490,
            540,
            80,
            35
          ],
          "style": "",
          "text": "clearchecks, checkitem $1"
        }
      },
      {
        "box": {
          "id": "obj-27",
          "linecount": 3,
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            230,
            540,
            80,
            49
          ],
          "presentation_linecount": 3,
          "presentation_rect": [
            230,
            540,
            80,
            49
          ],
          "style": "",
          "text": "$1, clearchecks, checkitem $1"
        }
      },
      {
        "box": {
          "id": "obj-20",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            330,
            640,
            49,
            20
          ],
          "presentation_rect": [
            330,
            640,
            49,
            20
          ],
          "style": "",
          "text": "Umenu"
        }
      },
      {
        "box": {
          "id": "obj-11",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            745,
            115,
            22,
            20
          ],
          "presentation_rect": [
            745,
            115,
            22,
            20
          ],
          "style": "",
          "text": "id"
        }
      },
      {
        "box": {
          "id": "obj-6",
          "maxclass": "comment",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            575,
            335,
            88,
            20
          ],
          "presentation_rect": [
            575,
            335,
            88,
            20
          ],
          "style": "",
          "text": "Index (umenu)"
        }
      },
      {
        "box": {
          "id": "obj-4",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 3,
          "outlettype": [
            "bang",
            "",
            "bang"
          ],
          "patching_rect": [
            230,
            220,
            79,
            22
          ],
          "presentation_rect": [
            230,
            220,
            79,
            22
          ],
          "style": "",
          "text": "t b l b"
        }
      },
      {
        "box": {
          "id": "obj-21",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            40,
            330,
            65,
            22
          ],
          "presentation_rect": [
            40,
            330,
            65,
            22
          ],
          "style": "",
          "text": "symbol $1"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-12",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            "int"
          ],
          "patching_rect": [
            230,
            510,
            29.5,
            22
          ],
          "presentation_rect": [
            230,
            510,
            29.5,
            22
          ],
          "style": "",
          "text": "i"
        }
      },
      {
        "box": {
          "id": "obj-8",
          "items": "<empty>",
          "maxclass": "umenu",
          "numinlets": 1,
          "numoutlets": 3,
          "outlettype": [
            "int",
            "",
            ""
          ],
          "parameter_enable": 0,
          "patching_rect": [
            40,
            440,
            100,
            22
          ],
          "presentation_rect": [
            40,
            440,
            100,
            22
          ],
          "style": ""
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-14",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 2,
          "outlettype": [
            "",
            ""
          ],
          "patching_rect": [
            330,
            270,
            119,
            22
          ],
          "presentation_rect": [
            330,
            270,
            119,
            22
          ],
          "style": "",
          "text": "routepass dictionary"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-10",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            40,
            300,
            123,
            22
          ],
          "presentation_rect": [
            40,
            300,
            123,
            22
          ],
          "style": "",
          "text": "dict.unpack identifier:"
        }
      },
      {
        "box": {
          "comment": "Index (umenu)",
          "id": "obj-3",
          "index": 1,
          "maxclass": "inlet",
          "numinlets": 0,
          "numoutlets": 1,
          "outlettype": [
            "int"
          ],
          "patching_rect": [
            600,
            360,
            30,
            30
          ],
          "presentation_rect": [
            600,
            360,
            30,
            30
          ],
          "style": ""
        }
      },
      {
        "box": {
          "comment": "Umenu",
          "id": "obj-2",
          "index": 1,
          "maxclass": "outlet",
          "numinlets": 1,
          "numoutlets": 0,
          "patching_rect": [
            290,
            630,
            30,
            30
          ],
          "presentation_rect": [
            290,
            630,
            30,
            30
          ],
          "style": ""
        }
      },
      {
        "box": {
          "comment": "id",
          "id": "obj-1",
          "index": 2,
          "maxclass": "inlet",
          "numinlets": 0,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            740,
            140,
            30,
            30
          ],
          "presentation_rect": [
            740,
            140,
            30,
            30
          ],
          "style": ""
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-36",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            40,
            270,
            161,
            22
          ],
          "presentation_rect": [
            40,
            270,
            161,
            22
          ],
          "style": "",
          "text": "dict.unpack #2:"
        }
      },
      {
        "box": {
          "color": [
            0.941176,
            0.690196,
            0.196078,
            1
          ],
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-35",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 2,
          "outlettype": [
            "",
            ""
          ],
          "patching_rect": [
            40,
            190,
            165,
            22
          ],
          "presentation_rect": [
            40,
            190,
            165,
            22
          ],
          "saved_object_attributes": {
            "_persistence": 1
          },
          "style": "",
          "text": "live.observer #2"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-34",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            640,
            652,
            161,
            22
          ],
          "presentation_rect": [
            640,
            652,
            161,
            22
          ],
          "style": "",
          "text": "prepend set #2"
        }
      },
      {
        "box": {
          "color": [
            0.941176,
            0.690196,
            0.196078,
            1
          ],
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-33",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            640,
            720,
            119,
            22
          ],
          "presentation_rect": [
            640,
            720,
            119,
            22
          ],
          "saved_object_attributes": {
            "_persistence": 1
          },
          "style": "",
          "text": "live.object"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-32",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 2,
          "outlettype": [
            "bang",
            ""
          ],
          "patching_rect": [
            640,
            582,
            30,
            22
          ],
          "presentation_rect": [
            640,
            582,
            30,
            22
          ],
          "style": "",
          "text": "t b l"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-30",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 4,
          "outlettype": [
            "dictionary",
            "",
            "",
            ""
          ],
          "patching_rect": [
            640,
            622,
            50.5,
            22
          ],
          "presentation_rect": [
            640,
            622,
            50.5,
            22
          ],
          "saved_object_attributes": {
            "embed": 0,
            "parameter_enable": 0
          },
          "style": "",
          "text": "dict"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-29",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            640,
            552,
            92,
            22
          ],
          "presentation_rect": [
            640,
            552,
            92,
            22
          ],
          "style": "",
          "text": "set identifier $1"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-25",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            640,
            522,
            73,
            22
          ],
          "presentation_rect": [
            640,
            522,
            73,
            22
          ],
          "style": "",
          "text": "fromsymbol"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-24",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            430,
            370,
            98,
            22
          ],
          "presentation_rect": [
            430,
            370,
            98,
            22
          ],
          "style": "",
          "text": "prepend append"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-23",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            330,
            540,
            98,
            22
          ],
          "presentation_rect": [
            330,
            540,
            98,
            22
          ],
          "style": "",
          "text": "prepend append"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-19",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            430,
            340,
            123,
            22
          ],
          "presentation_rect": [
            430,
            340,
            123,
            22
          ],
          "style": "",
          "text": "dict.unpack identifier:"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-18",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            430,
            300,
            27,
            22
          ],
          "presentation_rect": [
            430,
            300,
            27,
            22
          ],
          "style": "",
          "text": "iter"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-16",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            330,
            240,
            221,
            22
          ],
          "presentation_rect": [
            330,
            240,
            221,
            22
          ],
          "style": "",
          "text": "dict.unpack #1:"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-15",
          "maxclass": "newobj",
          "numinlets": 1,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            330,
            510,
            152,
            22
          ],
          "presentation_rect": [
            330,
            510,
            152,
            22
          ],
          "style": "",
          "text": "dict.unpack display_name:"
        }
      },
      {
        "box": {
          "id": "obj-13",
          "items": "<empty>",
          "maxclass": "umenu",
          "numinlets": 1,
          "numoutlets": 3,
          "outlettype": [
            "int",
            "",
            ""
          ],
          "parameter_enable": 0,
          "patching_rect": [
            600,
            440,
            99,
            22
          ],
          "presentation_rect": [
            600,
            440,
            99,
            22
          ],
          "style": ""
        }
      },
      {
        "box": {
          "color": [
            0.941176,
            0.690196,
            0.196078,
            1
          ],
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-9",
          "maxclass": "newobj",
          "numinlets": 2,
          "numoutlets": 2,
          "outlettype": [
            "",
            ""
          ],
          "patching_rect": [
            230,
            140,
            225,
            22
          ],
          "presentation_rect": [
            230,
            140,
            225,
            22
          ],
          "saved_object_attributes": {
            "_persistence": 1
          },
          "style": "",
          "text": "live.observer #1"
        }
      },
      {
        "box": {
          "fontname": "Arial",
          "fontsize": 12,
          "id": "obj-7",
          "maxclass": "message",
          "numinlets": 2,
          "numoutlets": 1,
          "outlettype": [
            ""
          ],
          "patching_rect": [
            290,
            440,
            37,
            22
          ],
          "presentation_rect": [
            290,
            440,
            37,
            22
          ],
          "style": "",
          "text": "clear"
        }
      }
    ],
    "lines": [
      {
        "patchline": {
          "destination": [
            "obj-33",
            1
          ],
          "order": 0,
          "source": [
            "obj-1",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-35",
            1
          ],
          "order": 2,
          "source": [
            "obj-1",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-9",
            1
          ],
          "order": 1,
          "source": [
            "obj-1",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-21",
            0
          ],
          "source": [
            "obj-10",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-27",
            0
          ],
          "source": [
            "obj-12",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-25",
            0
          ],
          "source": [
            "obj-13",
            1
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-15",
            0
          ],
          "source": [
            "obj-14",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-18",
            0
          ],
          "source": [
            "obj-14",
            1
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-23",
            0
          ],
          "source": [
            "obj-15",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-14",
            0
          ],
          "source": [
            "obj-16",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-15",
            0
          ],
          "order": 1,
          "source": [
            "obj-18",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-19",
            0
          ],
          "order": 0,
          "source": [
            "obj-18",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-24",
            0
          ],
          "source": [
            "obj-19",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-8",
            0
          ],
          "source": [
            "obj-21",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-33",
            0
          ],
          "source": [
            "obj-22",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-2",
            0
          ],
          "source": [
            "obj-23",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-13",
            0
          ],
          "order": 0,
          "source": [
            "obj-24",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-8",
            0
          ],
          "order": 1,
          "source": [
            "obj-24",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-29",
            0
          ],
          "source": [
            "obj-25",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-2",
            0
          ],
          "source": [
            "obj-27",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-2",
            0
          ],
          "source": [
            "obj-28",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-32",
            0
          ],
          "source": [
            "obj-29",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-13",
            0
          ],
          "order": 0,
          "source": [
            "obj-3",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-28",
            0
          ],
          "order": 1,
          "source": [
            "obj-3",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-34",
            0
          ],
          "source": [
            "obj-30",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-30",
            0
          ],
          "source": [
            "obj-32",
            1
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-30",
            0
          ],
          "source": [
            "obj-32",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-22",
            0
          ],
          "source": [
            "obj-34",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-36",
            0
          ],
          "source": [
            "obj-35",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-10",
            0
          ],
          "source": [
            "obj-36",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-12",
            0
          ],
          "source": [
            "obj-4",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-16",
            0
          ],
          "source": [
            "obj-4",
            1
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-7",
            0
          ],
          "source": [
            "obj-4",
            2
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-13",
            0
          ],
          "order": 0,
          "source": [
            "obj-7",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-2",
            0
          ],
          "order": 1,
          "source": [
            "obj-7",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-8",
            0
          ],
          "order": 2,
          "source": [
            "obj-7",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-12",
            0
          ],
          "source": [
            "obj-8",
            0
          ]
        }
      },
      {
        "patchline": {
          "destination": [
            "obj-4",
            0
          ],
          "source": [
            "obj-9",
            0
          ]
        }
      }
    ],
    "styles": [
      {
        "name": "Audiomix",
        "default": {
          "bgfillcolor": {
            "type": "gradient",
            "color1": [
              0.376471,
              0.384314,
              0.4,
              1
            ],
            "color2": [
              0.290196,
              0.309804,
              0.301961,
              1
            ],
            "color": [
              0.290196,
              0.309804,
              0.301961,
              1
            ],
            "angle": 270,
            "proportion": 0.39
          }
        },
        "parentstyle": "",
        "multi": 0
      },
      {
        "name": "Max 12 Regular",
        "parentstyle": "",
        "multi": 0
      },
      {
        "name": "Max For Live",
        "default": {
          "patchlinecolor": [
            0.239216,
            0.254902,
            0.278431,
            0.631373
          ]
        },
        "parentstyle": "",
        "multi": 0
      },
      {
        "name": "stb001",
        "default": {
          "fontname": [
            "Arial Bold"
          ],
          "fontface": [
            1
          ],
          "fontsize": [
            10
          ]
        },
        "parentstyle": "",
        "multi": 0
      }
    ]
  }
}