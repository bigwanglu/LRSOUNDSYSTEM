autowatch = 1;
inlets = 1;
outlets = 1;

mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

var xPos = 0.0;
var yPos = 0.0;
var zPos = 0.0;
var focusSize = 0.6;
var dragging = "";
var centerSnap = 1;
var snapRange = 0.06;
var speakerLevels = {};

var speakers = [
  { name: "L",   x: -0.92, y:  0.92, z: 0 },
  { name: "C",   x:  0.00, y:  0.92, z: 0 },
  { name: "R",   x:  0.92, y:  0.92, z: 0 },
  { name: "LFE", x:  0.00, y:  0.72, z: 0 },
  { name: "Ls",  x: -0.92, y:  0.05, z: 0 },
  { name: "Rs",  x:  0.92, y:  0.05, z: 0 },
  { name: "Lrs", x: -0.92, y: -0.92, z: 0 },
  { name: "Rrs", x:  0.92, y: -0.92, z: 0 },
  { name: "Ltf", x: -0.33, y:  0.40, z: 1 },
  { name: "Rtf", x:  0.33, y:  0.40, z: 1 },
  { name: "Ltr", x: -0.33, y: -0.55, z: 1 },
  { name: "Rtr", x:  0.33, y: -0.55, z: 1 }
];

var hitSpeakers = [
  { name: "L",   x: -0.78, y:  0.62, z: 0 },
  { name: "C",   x:  0.00, y:  0.70, z: 0 },
  { name: "R",   x:  0.78, y:  0.62, z: 0 },
  { name: "Ls",  x: -0.84, y:  0.00, z: 0 },
  { name: "Rs",  x:  0.84, y:  0.00, z: 0 },
  { name: "Lrs", x: -0.72, y: -0.66, z: 0 },
  { name: "Rrs", x:  0.72, y: -0.66, z: 0 },
  { name: "Ltr", x: -0.72, y: -0.88, z: 1 },
  { name: "Rtr", x:  0.72, y: -0.88, z: 1 }
];

function clamp(v, lo, hi) {
  return Math.max(lo, Math.min(hi, v));
}

function paint() {
  var r = box.rect;
  var w = r[2] - r[0];
  var h = r[3] - r[1];
  var pad = Math.min(w - 34, h - 12);
  var left = 17 + Math.max(0, (w - 34 - pad) * 0.5);
  var top = 6 + Math.max(0, (h - 12 - pad) * 0.5);
  var railLeft = left - 10;
  var railRight = left + pad + 8;

  drawBackground(w, h);
  drawZRail(railLeft, top, pad);
  drawZRail(railRight, top, pad);
  drawPad(left, top, pad);
  drawSpeakers(left, top, pad);
  drawObject(left, top, pad);
}

function drawBackground(w, h) {
  with (mgraphics) {
    set_source_rgba(0.026, 0.029, 0.034, 1.0);
    rectangle(0, 0, w, h);
    fill();
  }
}

function drawPad(left, top, size) {
  with (mgraphics) {
    set_source_rgba(0.045, 0.050, 0.058, 1.0);
    rectangle(left, top, size, size);
    fill();

    set_source_rgba(0.20, 0.21, 0.23, 1.0);
    set_line_width(1.0);
    rectangle(left + 0.5, top + 0.5, size - 1, size - 1);
    stroke();

    set_source_rgba(0.18, 0.19, 0.21, 0.82);
    set_line_width(1.0);
    move_to(left + size * 0.5, top + size * 0.15);
    line_to(left + size * 0.5, top + size * 0.88);
    move_to(left + size * 0.15, top + size * 0.5);
    line_to(left + size * 0.85, top + size * 0.5);
    stroke();
  }
}

function drawZRail(x, top, size) {
  var railH = size;
  var fillH = railH * zPos;
  with (mgraphics) {
    set_source_rgba(0.045, 0.050, 0.058, 1.0);
    rectangle(x, top, 4, railH);
    fill();

    set_source_rgba(0.96, 0.76, 0.04, 0.95);
    rectangle(x, top + railH - fillH, 4, fillH);
    fill();

    set_source_rgba(0.20, 0.21, 0.23, 1.0);
    set_line_width(1.0);
    rectangle(x + 0.5, top + 0.5, 3, railH - 1);
    stroke();
  }
}

function drawSpeakers(left, top, size) {
  var i;
  for (i = 0; i < speakers.length; i += 1) {
    var sp = speakers[i];
    var p = normToPixel(sp.x, sp.y, left, top, size);
    var level = speakerLevels[sp.name] || 0.0;
    var r = 2.8 + level * 7.5;
    var alpha = 0.20 + level * 0.78;
    with (mgraphics) {
      set_line_width(1.1);
      if (sp.name === "LFE") {
        set_source_rgba(0.66, 0.70, 0.64, Math.min(1.0, alpha + 0.10));
        ellipse(p[0] - r, p[1] - r, r * 2, r * 2);
        stroke();
      } else if (level > 0.58) {
        set_source_rgba(0.96, 0.78, 0.04, alpha);
        ellipse(p[0] - r, p[1] - r, r * 2, r * 2);
        stroke();
        set_source_rgba(0.96, 0.78, 0.04, alpha * 0.55);
        ellipse(p[0] - r * 0.45, p[1] - r * 0.45, r * 0.9, r * 0.9);
        fill();
      } else {
        set_source_rgba(0.58, 0.88, 0.24, Math.min(1.0, alpha + 0.12));
        ellipse(p[0] - r, p[1] - r, r * 2, r * 2);
        stroke();
        set_source_rgba(0.58, 0.88, 0.24, Math.min(1.0, alpha * 0.70));
        ellipse(p[0] - r * 0.45, p[1] - r * 0.45, r * 0.9, r * 0.9);
        fill();
      }

      set_source_rgba(0.96, 0.97, 0.98, 1.0);
      select_font_face("Avenir Next Condensed");
      set_font_size(9.5);
      move_to(p[0] - textOffset(sp.name), p[1] + r + 8);
      show_text(sp.name);
    }
  }
}

function drawObject(left, top, size) {
  var p = normToPixel(xPos, yPos, left, top, size);
  var radius = 12 + (1.0 - focusSize) * 30;
  var alpha = 0.06 + zPos * 0.72;
  with (mgraphics) {
    set_source_rgba(0.96, 0.78, 0.04, alpha * 0.36);
    ellipse(p[0] - radius * 1.45, p[1] - radius * 1.45, radius * 2.9, radius * 2.9);
    fill();

    set_source_rgba(0.98, 0.74, 0.05, alpha);
    ellipse(p[0] - radius, p[1] - radius, radius * 2, radius * 2);
    fill();

    set_source_rgba(1.0, 0.86, 0.22, 0.22 + zPos * 0.62);
    set_line_width(1.3);
    ellipse(p[0] - radius, p[1] - radius, radius * 2, radius * 2);
    stroke();
  }
}

function textOffset(s) {
  return Math.max(7, s.length * 2.4);
}

function normToPixel(x, y, left, top, size) {
  return [
    left + (x + 1.0) * 0.5 * size,
    top + (1.0 - (y + 1.0) * 0.5) * size
  ];
}

function pixelToNorm(px, py, left, top, size) {
  var x = ((px - left) / size) * 2.0 - 1.0;
  var y = 1.0 - ((py - top) / size) * 2.0;
  return [clamp(x, -1.0, 1.0), clamp(y, -1.0, 1.0)];
}

function layout() {
  var r = box.rect;
  var w = r[2] - r[0];
  var h = r[3] - r[1];
  var pad = Math.min(w - 34, h - 12);
  var left = 17 + Math.max(0, (w - 34 - pad) * 0.5);
  var top = 6 + Math.max(0, (h - 12 - pad) * 0.5);
  return { left: left, top: top, size: pad };
}

function onclick(px, py) {
  var l = layout();
  if (px >= l.left && px <= l.left + l.size && py >= l.top && py <= l.top + l.size) {
    dragging = "xy";
    setXYFromMouse(px, py);
  } else {
    dragging = "z";
    setZFromMouse(py);
  }
}

function ondrag(px, py) {
  if (dragging === "xy") {
    setXYFromMouse(px, py);
  } else if (dragging === "z") {
    setZFromMouse(py);
  }
}

function onidleout() {
  dragging = "";
}

function setXYFromMouse(px, py) {
  var l = layout();
  var n = pixelToNorm(px, py, l.left, l.top, l.size);
  xPos = applyCenterSnap(n[0]);
  yPos = applyCenterSnap(n[1]);
  outputState();
}

function setZFromMouse(py) {
  var l = layout();
  zPos = clamp(1.0 - ((py - l.top) / l.size), 0.0, 1.0);
  outputState();
}

function outputState() {
  outlet(0, [xPos, yPos, zPos]);
  mgraphics.redraw();
}

function applyCenterSnap(v) {
  if (centerSnap && Math.abs(v) <= snapRange) {
    return 0.0;
  }
  return v;
}

function x(v) {
  xPos = applyCenterSnap(clamp(v, -1.0, 1.0));
  mgraphics.redraw();
}

function y(v) {
  yPos = applyCenterSnap(clamp(v, -1.0, 1.0));
  mgraphics.redraw();
}

function z(v) {
  zPos = clamp(v, 0.0, 1.0);
  mgraphics.redraw();
}

function focus(v) {
  focusSize = clamp(v > 1.0 ? v / 100.0 : v, 0.0, 1.0);
  mgraphics.redraw();
}

function list() {
  var a = arrayfromargs(arguments);
  if (a.length >= 12) {
    setLevelsFromList(a);
  } else if (a.length >= 3) {
    xPos = applyCenterSnap(clamp(a[0], -1.0, 1.0));
    yPos = applyCenterSnap(clamp(a[1], -1.0, 1.0));
    zPos = clamp(a[2], 0.0, 1.0);
    mgraphics.redraw();
  }
}

function levels() {
  setLevelsFromList(arrayfromargs(arguments));
}

function setLevelsFromList(a) {
  var order = ["L", "R", "C", "LFE", "Ls", "Rs", "Lrs", "Rrs", "Ltf", "Rtf", "Ltr", "Rtr"];
  for (var i = 0; i < order.length; i += 1) {
    speakerLevels[order[i]] = i < a.length ? clamp(a[i], 0.0, 1.0) : 0.0;
  }
  mgraphics.redraw();
}

function reset() {
  xPos = 0.0;
  yPos = 0.0;
  zPos = 0.0;
  focusSize = 0.6;
  speakerLevels = {};
  outputState();
}

function reset_xy() {
  xPos = 0.0;
  yPos = 0.0;
  outputState();
}

function reset_z() {
  zPos = 0.0;
  outputState();
}

function reset_all() {
  reset();
}

function snap(v) {
  centerSnap = v ? 1 : 0;
  xPos = applyCenterSnap(xPos);
  yPos = applyCenterSnap(yPos);
  outputState();
}

function snap_range(v) {
  snapRange = clamp(v, 0.0, 0.25);
  xPos = applyCenterSnap(xPos);
  yPos = applyCenterSnap(yPos);
  outputState();
}
