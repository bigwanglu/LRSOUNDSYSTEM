autowatch = 1;
outlets = 2;

function msg_float(v) {
  map(v);
}

function msg_int(v) {
  map(v);
}

function map(v) {
  var n = Math.max(0, Math.min(100, Number(v)));
  var hz = n <= 50
    ? 20 * Math.pow(50, n / 50)
    : 1000 * Math.pow(20, (n - 50) / 50);
  outlet(0, hz);
  outlet(1, hz);
}
